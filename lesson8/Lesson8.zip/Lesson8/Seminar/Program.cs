﻿using Seminar.MyUtils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seminar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            OutputHelpers.PrintInfo(8, "Байраковский Станислав Антонович");

#if DEBUG
            Console.Title = Properties.Settings.Default.ApplicationNameDebug;

#else
            Console.Title = Properties.Settings.Default.ApplicationName;

#endif

            Console.WriteLine($"Настройка UserSettings1: {Properties.Settings.Default.UserSettings1}");
            Console.WriteLine($"Настройка UserSettings2: {Properties.Settings.Default.UserSettings2}");

            Console.Write("Укажите значение UserSettings1: ");
            Properties.Settings.Default.UserSettings1 = int.Parse(Console.ReadLine());

            Console.Write("Укажите значение UserSettings2: ");
            Properties.Settings.Default.UserSettings2 = Console.ReadLine();
            Properties.Settings.Default.Save();

            Console.WriteLine($"Настройка UserSettings1: {Properties.Settings.Default.UserSettings1}");
            Console.WriteLine($"Настройка UserSettings2: {Properties.Settings.Default.UserSettings2}");

            // %userprofile%\AppData\Local


            Console.ReadKey(true);
        }
    }
}
