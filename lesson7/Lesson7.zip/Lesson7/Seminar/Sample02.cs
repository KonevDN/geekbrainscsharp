﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seminar
{
    internal class Sample02
    {
        static void Main(string[] args)
        {
            int x = 1;
            double y = 3.14;
            Person person = new Person();

            Console.WriteLine($"Generation >>> {GC.GetGeneration(person)}");

            DoProcess();

            GC.Collect();

            Console.WriteLine($"Generation >>> {GC.GetGeneration(person)}");

            
            GC.Collect();
            GC.Collect();
            GC.Collect();
            GC.Collect();
            GC.Collect();

            Console.WriteLine($"Generation >>> {GC.GetGeneration(person)}");

            Console.ReadKey(true);
        }

        static void DoProcess()
        {
            Person person = new Person();
            string str = "";
        }

    }

    class Person
    {

    }
}
