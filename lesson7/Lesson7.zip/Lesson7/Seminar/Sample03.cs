﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seminar
{
    internal class Sample03
    {
        static void Main(string[] args)
        {
            string str = "";
            Stopwatch sw = new Stopwatch();
            sw.Restart();
            for (int i = 0; i < 30000; i++)
            {
                str += Guid.NewGuid(); // Добавляем строковый идентификатор
            }
            sw.Stop();


            Console.WriteLine(sw.ElapsedMilliseconds);
            StringBuilder stringBuilder = new StringBuilder(10000);
            sw.Restart();
            for (int i = 0; i < 30000; i++)
            {

                stringBuilder.Append(Guid.NewGuid()); // Добавляем строковый идентификатор
            }
            sw.Stop();
            Console.WriteLine(sw.ElapsedMilliseconds);

            Console.ReadKey(true);
        }
    }
}
